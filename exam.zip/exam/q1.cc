// You can write your code in C or C++. Modify this file and the makefile
// accordingly. Please test your program on CSE linux machines before submitting
// your solution.
//

#include<stdio.h>

int main(int argc, const char* argv[])
{
  printf("Please modify the source of this program.\n");

  return 0;
}
